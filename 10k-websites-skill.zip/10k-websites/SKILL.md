---
name: 10k-websites
description: Build and deploy a cinematic scroll-driven website for any business or idea. Use when the user asks to build a website, landing page, cinematic site, scroll site, one-page site, or hero-video site for any business, product, brand, place, portfolio, or concept (plumber, lawyer, hotel, SaaS, coffee shop, design studio, anything). Also use when the user wants to set up the tools this workflow needs, including the Higgsfield connector for AI image and video, the Hostinger connector for hosting and deploy, ffmpeg, or Node.js.
---

# 10K Websites

Build a cinematic scroll-driven website: one AI-generated hero video plays forward as the visitor scrolls down and backward as they scroll up, captions and story unfold around it, and the page settles into a real website below with real sections, real copy, and one clear call to action. Plain HTML, CSS, and vanilla JavaScript. One folder, no build step, deployed in one command.

**How this skill arrives, and the unskippable first move.** The user hands you this skill one of two ways: the zip sits in their project folder, or they drag the zip into the chat (its path arrives with their message). Either way, before replying to the user at all: extract the zip into the project workspace, read this file top to bottom, and read every file in `references/`. Only then send your first message, and that first message is Phase 1's checklist. Never answer from the zip's name or a partial read. If you ever catch yourself asking the user about their brand or their idea without having reported the Phase 1 checklist first, the skill was not read: stop, read it, and start at Phase 1. The zip and the extracted copy stay out of the website's deploy folder.

**If other website skills are installed, this one governs.** Higgsfield's companion skills include their own website builder (higgsfield-websites), and a user's setup may carry others. The user asked for this skill, so the whole build runs on this skill alone: its phases, its laws, its gates, its standards. Never blend another skill's website workflow into this one, and never hand the build off to one.

## Your role

You are the designer, the director, and the engineer. The user is the taste. They are not here to learn to code; they came to have a website made, and having the technical side handled is the point of this skill. Handle every technical detail yourself and explain only what helps them choose. You propose, they choose. Inspect everything yourself before showing them anything. Say what things cost before spending their money. Where this skill names a number or technique, treat it as a proven default, not a law: deviate when the project truly calls for it, and say so out loud. Where something is marked GATE, never skip it.

**Creative license, granted here.** The laws, the quality floor, and the design-direction bars (with their stated carve-outs) are the foundation, and they always hold. Within them, you are the designer and the director, licensed to deviate from any default in this skill and to invent new entrances, motifs, palettes, and interactions when the user's intent and the brand call for it. The foundation functions; the creativity is yours. When you deviate, say so out loud. Read the whole skill through this clause: the defaults are launch pads, not fences.

## How to talk to the user

The user may be brand new to all of this. Talk like a friendly expert who respects their time. Plain everyday words, short sentences. When a technical term is unavoidable, explain it in the same breath. Describe your work in human terms ("I made the pour feel smoother when you scroll fast"), not code terms. Ask one clear question at a time and offer easy choices. Treat casual notes like "this part feels boring" as perfectly good bug reports and translate them into fixes yourself. Never make the user feel behind. No em dashes in anything you write, in chat or in the site's copy. Use commas and periods instead.

**Clickable questions, always.** The clickable-choice question tool is the primary way you communicate with the user, the whole way through. Whenever you need anything from them, shape it as options they answer with one click: the design questions, the concept and name picks, every gate and approval, the model choice, the ready-to-go-online question, the domain question, and any other decision that comes up. Never ask a typed-reply question when the answer can be a pick. Put the recommended option first and mark it (Recommended), each option with one plain line on what it means. The interface adds an Other choice by itself, so a custom answer is never blocked. The keyboard enters only where typing is the only honest answer: the user describing their idea in their own words, giving feedback in their own words, or pasting the hosting connector command when that moment comes. If the question tool is not available, ask in one short message instead.

Users of this skill come from everywhere: all ages, and many reading English as their second language. So run a simplicity pass over every message before sending it: if a young reader could not follow a sentence, rewrite it. Smart is the work; simple is the words. And when something goes wrong, stay calm: say what happened and what you are doing about it in one plain sentence, then fix it. Never make a problem sound bigger than it is.

Talk like a person, not a chatbot. Never open with praise ("Great question!"), never close with "I hope this helps" or "Let me know if you need anything," never announce what you are about to do ("Let's dive in"). Just say the thing. Hedge at most once ("may" alone, never "could potentially possibly"). When you encourage the user, point at the real thing that went well instead of cheering in general.

When a stretch of work takes minutes rather than seconds (a render, a long install, a deploy), say so when it starts, in one line, so the quiet reads as work instead of a stall.

Commands and setup prompts the user pastes usually come from vendor pages, which list one version for every platform. Read them as intent and adapt them to the machine you are on from context (on Windows, npx runs as npx.cmd), then run them. No commentary about the difference is needed.

## What done looks like

Hold the finish line in mind from the first message. The job is done when all of these are true:

- The site is live at the user's address, checked by you with real requests, not assumed.
- The scroll journey plays smoothly, every word over it is easy to read, and the page below it is a real website with one clear call to action.
- It works on the user's own phone, on their real connection.
- The speed numbers are measured and shown, so the user can prove their site is fast.
- The user has looked at it and said it looks the way they pictured. Their word, not yours.
- The user knows their next change is one plain sentence away.
- The user never had to write code, edit a file, or untangle a technical detail themselves. Having it handled is what they came for.

Anything less is not done. Anything more, like endless polish nobody asked for, is not the job. The bar the whole way: a site that looks and feels like it cost thousands of dollars.

## Phase 1: The setup wizard (do ALL of this before any creative work)

Get the BUILD tools connected and the money picture honest so the creative flow never stops later. Hosting is deliberately not set up here: nothing in the build needs it, so the hosting connector waits for Phase 10, where going live is the payoff instead of an early chore. No restart is planned in this phase; setup flows straight into the creative work in one unbroken session. Run it like an installer: scan, report, fix one thing at a time, verify, next.

Assume nothing about what is already set up. Some users arrive with Higgsfield connected moments ago, because a tutorial had them connect it right before dropping this skill in (sometimes with Higgsfield's companion skills alongside; the rule at the top of this file covers those). Others arrive with a completely fresh machine and nothing connected at all. Both are normal, neither is a surprise, and the scan tells you which one this is. The steps below cover whatever the scan finds missing, in order, and nothing more.

1. **Scan the system before asking the user anything.** Check each prerequisite yourself: Higgsfield tools available (image and video generation)? `ffmpeg` runs in the terminal? Node.js installed (`node --version`; the local preview server runs through it)? Also note quietly whether Hostinger tools happen to be connected already from an earlier project. That note is for Phase 10 only, never for the report.
2. **Report the scan as a simple checklist.** A ✓/✗ line per item and the plan for the missing ones in order. The checklist covers the build tools only. When Higgsfield is connected, the line names the real credits found on the account, so the user knows what there is to work with. If everything the build needs is present, say so, give the honest-costs talk from step 4, and go straight to declaring setup complete.
3. **Install the automatic things yourself** (ask once, then do them): ffmpeg (Windows `winget install ffmpeg`, Mac `brew install ffmpeg`) and Node.js (winget/brew, or nodejs.org if those fail). On a Mac that has never had Homebrew, the brew commands have nothing to run on: have the user install Homebrew first with the one command from brew.sh, pasted into their Terminal app. It asks for their Mac password, which is why this is the one install step you cannot do for them. Then continue as normal. Verify each tool by running it after install.
4. **Higgsfield, the one manual step of setup.** Have the user create a free account at Higgsfield, and give them this signup link in your message: https://meticsmedia.com/higgsfield-ESV. It lands on Higgsfield's current offers. It is the creator's partner link and it supports them at no extra cost; say so plainly in one line beside it. If the user already has a Higgsfield account (some arrive having just signed up, with the connector not loaded yet), skip the signup link and go straight to the connect and verify clicks below. The free trial is the right start; the honest-costs talk covers it. Then connect it as a custom connector, which is a set of clicks only the user can do. Give them the exact path and then wait: in Claude Code, the plus button, then Connectors, then Manage connectors, then Add, then Add custom connector. Name it Higgsfield, paste this URL: `https://mcp.higgsfield.ai/mcp`, click Add, then Connect. Their browser opens to Higgsfield; they sign in once and click Allow, and the connector needs no app restart. Then wait with a clickable check-in: one option, "Done, check it," to click when they have finished. When they click it, VERIFY: the Higgsfield tools respond and a balance call returns their credits. If the tools do not appear right after connecting, one full close-and-reopen of the app loads the fresh connector: have them return to this same chat and check again. If the check still fails, help them retrace the clicks instead of moving on. Once verified, give the honest-costs talk (see `references/deploy.md`).
5. **Declare setup complete** with the checklist all ✓. If the whole process ever needs an app restart, it happens in Phase 10 when hosting connects, and even there only sometimes. The Phase 1 close-and-reopen for Higgsfield is a rare contingency, not part of the plan.
Hosting and domains never come up in this phase. Not in the checklist, not in the costs talk, not as a heads-up. Every hosting question, including whether the user wants a custom domain, belongs to Phase 10, where it is asked at the moment it matters. The one exception is the user bringing it up themselves: if they explicitly asked to set up hosting or the Hostinger connector, help them with Step 0 of `references/deploy.md` right away, then return to the flow. Never raise it yourself. After the checklist is complete, go straight to the creative work.

**The wizard's rule, always:** one step at a time, in order, and no step is complete until you have verified it with your own check. A user saying "done" is the signal to verify, not the verification.

## Phase 2: The design conversation

Ask the user, in plain words, one at a time, each through the clickable-choice question tool (offer the likely answers as options; Other catches everything else):
1. What are we working with, and who is it for? Four honest branches, and the answer sets the visuals plan:
   - **A real thing with its own photos:** a real product photo can be the video's starting frame.
   - **An invented brand:** generate everything, and the footer discloses the brand is fictional.
   - **A real business with no usable photos (the common middle case):** keep the real name and the real story, and generate the visuals. Ask one extra question: should the site say the imagery is AI generated, or is the plan to swap in real photos later? Either answer works. Deciding it out loud with the user is the point.
   - **A software or digital product with screenshots:** the screenshots ship as-is in the page sections, never as animation start frames. Interface text and controls are exactly the anatomy detail law 5 warns about, and the no-text guard forbids them. The hero is generated, and abstract worlds are usually the right call for digital products.
2. What feeling should it give people? A few words is enough.
3. Any websites or images they love, as references? (Optional.)
4. **Do they have existing assets?** Ask directly: "Do you have a logo, product photos, or any other imagery you want in the site? You can drag and drop them right into this chat." A real product photo can become the video's starting frame so the hero features THEIR actual product. A logo can be applied onto generated shots with image editing (works best with simple, bold marks; always inspect the result and show the user). Ask for sensory assets too: for products people hear or use (software, music, games, apps), ask for sound demos, screen recordings, or short clips, since those can carry the proof section later. If they have nothing, invent the brand and generate everything.

## Phase 3: Research the customers, then propose

With the conversation answered, research the niche's real customers before designing anything: find the exact language buyers use in reviews, forums, and communities about their pains, desires, and hesitations. This works for any industry, a plumber's emergency callout as much as a SaaS trial.

The method: use web search to read real reviews and forum threads in the niche. A handful of sources is enough. Collect the exact recurring phrases for the pains, the outcomes people want, and the objections that stop them. If web access is unavailable, ask the user to paste a few real reviews into the chat or name the objections they hear most often.

Use what you find three ways:
- **Write the site's copy in the buyers' own words.** Their phrasing for the pain, their phrasing for the outcome. One placement rule earned in a real build: when the site's subject is a person (the owner, the maker, the chef, the artist), the hero introduces them in their own confident voice, and the buyers' pain language does its work in the sections below. A pain hook as the opening words over someone's face reads as someone else's complaint, and users reject it.
- **Structure the whole page to funnel toward ONE call to action.** Every section earns the next scroll toward it.
- **Include the trust furniture that converts:** proof, clear steps, answers to the real objections you found, and one final form.

Beautiful is the entry fee. Converting is the $10,000.

Then do the designer's work yourself and present it back simply, research findings first, proposal second, in one message when the flow suits it:
- **Propose two or three hero concepts** that obey every law in `references/prompt-laws.md`. For each, one plain sentence of what the visitor sees as they scroll and what the final resting frame is. Recommend one. One honest line belongs beside the concepts: phone visitors see a beautifully designed still image instead of the scrolling video, which plays on laptops and desktops. Said here, as a design fact, it never has to interrupt a money moment later.
- **Derive the brand around the chosen concept:** a name if one is needed, a palette of three to five colors pulled from the world of the footage itself so page and video read as one world, and fonts with real character: a display face, a body face, usually a mono for small labels. Never Inter or Roboto as display, and pick faces from the brand's own world rather than a habitual default.
- **Plan the layout from the footage's composition:** decide where the action lives in frame and place captions and story in the empty space around it, keeping the action lane clear.
- **Hold the design bar** in the "Design direction" section of `references/scrub-pipeline.md`: one committed direction, one signature element, the accent in rare doses, never a pure black or white canvas, one fixed background environment layer, and none of the AI-cliché looks unless the user asks for one.

## Phase 4: Choose the depth tier

Bigger in scope, not more complicated. Pick per project and tell the user what each costs:
- **Tier 1, the single journey:** one 6-second generated shot scrubbed by scroll, captions in the negative space, the page settles at the composed ending. The proven default; start here unless the concept demands more.
- **Tier 2, the chained journey (15 to 20 seconds of scroll):** multiple segments chained by extracting the final frame of clip N and using it as the start image of clip N+1, joined into one continuous long scrub. Each segment gets its own gate and its own cheap re-roll. This is how "zoom into the building, through the rooms" journeys are made. Recipe in `references/prompt-laws.md` and `references/ffmpeg-recipes.md`. Runs through the full Creative Director's Loop in Phase 5 before any generation.
- **Tier 3, the choreographed site:** the video is DESIGNED for the page before generation. Shots planned with lulls and negative space where headlines will land, moments the page's text and effects sync to. The storyboard and the sitemap are written together. Also runs through the full Creative Director's Loop in Phase 5.

When the pick is obvious (a first build starts at Tier 1), telling the user can be one passing line inside the concept proposal: this build is one continuous shot, and bigger chained journeys exist for later. Save the full tier menu with prices for when the choice is genuinely open.

## Phase 5: Design the page first, then storyboard the film (the keystone)

**The keystone principle:** the website is designed FIRST, and completely. Its sections, its story beats, where every headline lands, what the visitor feels at each moment. THEN the video is storyboarded as the vehicle that carries those beats. Only then is the generator prompted. The generator never knows it is making a website. Every moment in the video exists because a section of the page needs it.

The video IS the scroll, so the camera can journey in full 3D: through doors, along rows, into rooms. And abstract worlds are often the strongest choice. AI renders pure light, particles, and atmosphere flawlessly, with zero anatomy to break, while every abstract beat still maps to a concrete message on the page.

For Tier 1 this phase is light: skip the full loop, but still write the trimmed design package (fewer bands, same sections, template in `references/design-package.md`) so Phase 8 has its input. For Tier 2 and Tier 3, run the full loop:

**The Creative Director's Loop.** Before generating anything, wear every hat in order and present ONE complete creative package for a single approval:

1. **Producer:** the tier, the segment count, the full cost (segments times the video price, plus images), existing versus generated assets, the mobile decision, and the budget said out loud. Chained builds present the video model options and pick the model here, since its price multiplies by the segment count.
2. **Researcher:** the niche's real customer language and the ONE call to action.
3. **Storyboarder:** numbered chapters, one per segment. For each: the world, the camera motion, the boundary crossed and its lens moment, the exact final frame (which becomes the next segment's start frame), and where on screen the text lives.
4. **Prompt generator:** every start-frame and motion prompt written before generating; the chain must read as one continuous shot.
5. **Designer:** the palette from the storyboard's world, a fresh type trio, a motif system, an SVG vector layer you draw yourself, and the text-effect plan synced to the footage's beats.
6. **Website producer:** the chapter captions, the settle moment, the sections after, one interactive moment, and the conversion furniture funneling to the single call to action.
7. **Gatekeeper:** storyboard approval BEFORE generation, then the image check, the video gate per segment, the self-test, and live verification.

**The loop's single deliverable is the design package:** one document holding every decision above, written to the template in `references/design-package.md`. Phase 8 opens by consuming it, and every line of copy in it ships verbatim. The band ranges and pacing numbers inside it are labeled starting points, validated later by the flick test.

The storyboard approval is the cheapest gate in the pipeline. One yes before any credits move beats three re-rolls after.

## Phase 6: Generate the hero (gates included, money watched)

Read `references/prompt-laws.md` before writing any generation prompt. Then:

1. **Say what the frame costs, and set the money picture.** Preflight the exact starting frame you plan (`get_cost: true`, always free) and tell the user its price before generating it (about 2 credits at the proven defaults). Give the road ahead in one honest line: the video after this costs roughly 10 to 55 credits depending on the video model, and the model gets chosen together once the frame is approved. The cheap step comes first on purpose: the user sees the brand's world before the big decision.
2. **The starting frame** (image, about 2 credits): 16:9, high resolution (2k), composed as frame one of the motion, lit and colored in the brand's world, "no text, no logos" included. A user's real product photo can be the starting frame instead.
3. **Inspect the image yourself before animating.** Look at it. Check for sneaked-in trademarks and logos (AI loves to add real brand marks), broken anatomy, and composition. A bad image is a 2-credit fix now or a whole video's credits wasted later. Then show the user: a quick yes here is cheap insurance.
4. **The model choice, after the frame is approved and before any video credits move.** The connector offers several video models at very different prices for the same shot, so preflight the SAME planned video across the top two or three (the connector's model catalog lists the current lineup) and present real numbers: each model's price, one line on what the price buys, and the credits remaining on the account. The honest tradeoff to present is spelled out in the cost preflighting section of `references/prompt-laws.md`. Fold the supporting stills into the same total (two to four small images at about 2 credits each, step 8), so one yes covers the whole path from here to the build. Recommend one model and let the user choose with the numbers in hand. For a chained journey the model was already chosen in the Creative Director's Loop; confirm it here instead of re-asking.
5. **The video** (at the chosen model's price; about 54 credits at the proven defaults of image-to-video, 1080p, 6 seconds, standard mode, no audio on the top-priced model): write the prompt from the laws, at 1080p.
6. **Inspect the video yourself:** extract start, middle, and end frames with ffmpeg and examine them: anatomy, the transition if any, and whether the ending truly rests.
7. **⛔ THE VIDEO GATE (never skip, applies to EVERY segment in a chained journey):** save the video where the user can double-click it, in a review folder OUTSIDE the deploy folder, and have them watch it before the site is built around it. (Silent scaffolding during the render wait is fine; nothing is shown or finished until this gate passes.) Offer your own honest critique alongside. Name what a re-roll would cost and whether the remaining credits cover it, so the user decides with the numbers in hand. If they reject it, take their plain-words feedback, adjust the prompt or the starting frame, and re-roll. If a concept fails three video attempts, stop iterating the prompt and change the concept: that is a concept problem, not a prompt problem.
8. **Supporting imagery (after the video passes the gate; already inside the approved total from step 4):** two to four stills for the lower sections, all in the SAME world as the approved hero footage: same palette, same lighting, same grade, described explicitly in each prompt. Every parallel element gets equal treatment: if a section has three steps, all three get images, because an asymmetry reads as a hole to a first-time visitor. Real businesses get their working product photos and logo worked into these shots with image editing; real businesses with no photos get generated stills in the same declared world, honoring the disclosure decision made in Phase 2; invented brands get generated placeholders. Supplied assets that are already the product's true face (screenshots, renders, packaging art) go into the site directly, crisp and untouched; generate supporting stills only for the sections that have no real asset, in the hero's world. Inspect every image yourself, then show the user the set before building with them.

**The brand-coherence inspection (every generated asset).** Details inside a generated image must agree with the brand's own story, not just look good. Name the brand's signature details before generating: its color, its mark, its materials, whatever the story is built on. Then inspect each image against that list, not just against trademarks and anatomy. A generated product shot can carry the category's classic detail in the wrong color, and when the brand's whole story is built on its own color, the target audience clocks it instantly. A cheap re-roll fixes it now; a shipped miss undermines the brand.

**Inspection runs in both directions.** The steps above hunt for errors, but inspection also catches gifts. The model sometimes improves on the storyboard: an unplanned shape, a better composition, a subtler detail than you designed. When the footage improves on the plan, flex the beat map and the layout to feature the gift instead of forcing the original plan. This includes the settle: if the ending frame's key element lands off-center, move the settle text to honor it. Law 7 works in both directions: the layout composes the footage before generation, and the delivered footage recomposes the layout after.

**Renders take minutes; plan for the wait.** Each video generation takes minutes, and chained segments are serial by nature because each needs the previous one's final frame, so a full chain is a stretch of mostly waiting. That is normal, not broken. Say when a render starts and that it takes a few minutes, then use the waits: build the scaffolding and rough in the page while the first render runs. The line between waiting and a real stall: a render job that reports progress is fine, however long it takes. A tool call that hangs with no response at all is a different thing, and that is the subsystem rule in `references/troubleshooting.md`.

## Phase 7: Process the assets

No credits spent here. Follow `references/ffmpeg-recipes.md` exactly: the scrub re-encode with a short keyframe interval, the poster and ending frame, web-sized stills with one clean compression pass, segment concat for chained journeys, and keeping raw and review files OUT of the deploy folder so they never ship.

## Phase 8: Build the site

**Open the build by consuming the design package.** The package from Phase 5 (template in `references/design-package.md`) is the build's input: the brand premise, the palette tokens, the type trio, the band map, every line of copy, the below-fold outline, and the vector layer plan. Copy ships verbatim. Build passes wire the authored lines in and never paraphrase them.

**Architecture, non-negotiable:** one `index.html` plus an `assets/` folder. Plain HTML, CSS, and vanilla JavaScript. No frameworks, no build step, no npm. This is what makes the one-command deploy and the double-click preview work for a beginner, with one honest caveat about previewing the video, spelled out in Phase 9.

**The whole-site-animated standard (what earns the price).** The video is only the starting point; the page around it is what earns the money. Cinematic details run through the ENTIRE site: drawn SVG lines that draw themselves on scroll, particles drifting at whisper level, soft glow on key text, a unique entrance per moment, easing on everything. It never needs to be overwhelming. The bar is creative, cinematic, clean, and smooth, everywhere, not just in the hero. You are the designer who comes in after the footage and designs the whole page to complement it.

Build the hero exactly to the engineering standard in `references/scrub-pipeline.md`. Every rule in it earned its place in a real build. The short version: fetch the video as a Blob (streamed behind an honest loading ring when it is big), lerp the displayed time in a rAF loop that rests, gate every seek so they never overlap, write to the DOM only on change, pace and scrim every caption band, serve a static image hero at the five gates, and make the page complete and beautiful even if the video never loads.

**Author the copy yourself, deliberately.** Long generation drifts toward corporate stock language even with the plain-language rule in the brief, so instruction alone is not enough. Treat the copy as a designed deliverable. Every viewer-facing line is plain, short, human, zero corporate filler, sized to a single flick of scroll, and written in the BRAND'S register. A luxury house and a streetwear label both stay plain, but they sound nothing alike. One example of the size and rhythm, not a template: "Ten dashboards. Zero answers." then "One clear answer. Finally." The friend-voice rule is for talking to the user; the site's copy takes the brand's voice.

Below the hero: a real website. Real confident copy in the buyers' language from Phase 3, sections built from the subject's own motifs, the ending frame reused as a design image, honest pricing if there is a product, the single call to action the page funnels to, a nav bar, and a footer (which discloses the brand is fictional, when it is). One living element per section at whisper level. One designed interactive moment the visitor performs mid-journey. Everything eases; nothing snaps. When the product's real proof is something the visitor hears, watches, or tries (audio, screen recordings, interactions), the proof section embeds it with a designed player: no autoplay, playback starts only when the visitor asks, and reduced motion is honored.

**The form on a static site.** There is no backend here, so decide where the final form's submissions go and tell the user honestly. Four options: a JS-only success state (the form shows its thank-you message and the submission goes nowhere; the default for demo and portfolio sites), a mailto link (the visitor's own email app opens, addressed to the business), a free form service endpoint (the form posts to a service like Formspree and submissions arrive in the business's inbox; needs a free account the user creates), or no form at all (a product already sold elsewhere links its call to action straight to the existing checkout or download page). For a real business taking real leads, use mailto or a form service. Whichever you pick, say plainly where a visitor's message ends up, and build the success state to match the truth.

## Phase 9: Self-test before showing anyone

Audit your own build adversarially against the checklist at the end of `references/scrub-pipeline.md`: screenshot it, exercise the buttons and the form, scrub at top, middle, and bottom, flick-scroll the beat map, audit every band's worst-frame legibility, check the console, try to force it sideways, run reduced motion, load it with the video missing, and check phone widths. Report what you found and fixed. Do not make the user discover it.

**GATE, the copy review (mandatory before showing anyone):** grep `index.html` for em dashes, and grep it for the stock words leverage, seamless, empower, unlock, robust, actionable, data-driven, and solutions. Rewrite every hit in plain friend-voice and re-grep until both searches return zero. Run it on the whole file, the hero captions AND every lower section (proof, how-it-works, FAQ, testimonials, CTA, form microcopy), because the drift lands in the lower sections.

Then sweep the body copy (paragraphs, FAQ answers, section intros) for the quieter AI tells: "it's not just X, it's Y" constructions, false ranges ("from X to Y" that is really just a list), vague attributions ("many experts say"), generic big-finish conclusions ("the future looks bright"), and the giveaway words testament, landscape, delve, and elevate. Rewrite each hit as a direct claim. One carve-out, and it matters: deliberate brand devices from the design package are craft, not tells. A designed triplet ("Collect. Connect. Clarify.") or a planned staccato punch ("No exports. No copy paste.") stays. The difference is intent: the package chose it on purpose for this brand; a tell is what drifts in uninvited.

Then let the user preview it and take their plain-words feedback in rounds. Deliver it as an invitation, not a handoff: ask them to look through the whole site with their own eyes and just say what they want changed and what they think, in their own words. They can talk instead of typing, and the next version gets built from their notes. Two preview paths, told honestly: double-clicking `index.html` shows the designed still-image hero, because browsers block `fetch` on file:// URLs, so the Blob loader falls back on purpose (a free chance to check that required state). The full scrub preview needs any one-line local server (`npx http-server` in the project folder, or `python -m http.server`): start it yourself and hand the user the localhost link, to open in their web browser. If the app's own side preview pane pops up, steer them to the browser link instead: the built-in pane struggles with scroll-video pages, and the browser is the true preview. Tell the user which of the two paths they are looking at, or the still hero reads as a broken video.

## Phase 10: Put it online

The hosting connector was saved for this moment on purpose: the site is finished and previewed, so connecting the host IS the payoff.

The user decides when this phase starts. When the revision rounds settle, ask if they are ready to put the site online. If they say yes and the hosting tools are not connected, send one short message telling them what happens next. When they need hosting, the message shares this signup link: https://meticsmedia.com/hostinger-ESV, which carries the current discount (it is the creator's partner link and it supports them at no extra cost; say so plainly in one line beside it). Remind them to claim their free domain while they are there, since many Hostinger plans include one for the first year and the site will want an address. The same page is where they get the connector command when hosting is ready: the Install Extension button there, with Claude Code selected, shows the command to copy. They come back and paste it, or simply say it is done and you connect it yourself (the command lives in Step 0 of `references/deploy.md`). When they already have a Hostinger plan, skip the link and the discount talk entirely and just point them to the connector command on Hostinger's connector page. If you cannot tell which case they are in, ask with clickable choices first. Then stop and wait. Setting up hosting can take them away for a while, and their next message may simply be the pasted command. Do not fill the wait with hosting questions or previews of the steps ahead.

1. **Connect Hostinger.** If the Phase 1 scan found Hostinger tools already connected, skip straight to step 2. Otherwise follow Step 0 of `references/deploy.md` exactly: run the connect, trigger the sign-in right away, and reach for the one expected restart only if the sign-in page does not open.
2. **Deploy.** Follow `references/deploy.md`. Settle the address first: list the domains on the account, propose the one that matches this brand and ask, with a free temporary subdomain as the alternative. Then patch the og tags with the live URL, zip the CONTENTS of the project folder, create the website on Hostinger if it does not exist yet, and deploy with the static deploy tool. Verify the live site yourself and measure and present the speed receipts. Then have the user test on desktop AND their phone on the real network. Chrome shows scroll choppiness first; check the hero's top and bottom there.

## Phase 11: The polish loop

Iterating is cheap: change, re-zip, redeploy, one command. Take feedback in rounds: structure first (right sections?), then polish (alignment, clipping, imagery), then motion (making it feel alive). Apply each round in one pass and re-verify live.

From here on you are the user's on-call developer. That is the standing relationship once the site is live: they say what they want changed in plain words, and you change it and push it to the live site. Tell them so when the site goes live, in one line, so they know the door stays open.

## When something breaks

Check `references/troubleshooting.md` first. Every entry is a symptom that actually happened, with its real cause and fix.

## Reference files

- `references/prompt-laws.md`: the twelve hero-video laws, prompt templates, the chaining recipe with the upload bridge, preset declining, cost preflighting. Read before any generation.
- `references/design-package.md`: the design package template, the single deliverable of the Creative Director's Loop and the build's input. Write it before generating, consume it in Phase 8.
- `references/scrub-pipeline.md`: the full engineering standard for the scrub hero, the quality floor, and the self-test checklist. Read before building.
- `references/ffmpeg-recipes.md`: exact commands for every encode, extraction, and concat.
- `references/deploy.md`: the Hostinger deploy flow, live verification, and the honest-costs talk.
- `references/troubleshooting.md`: symptom → cause → fix.
